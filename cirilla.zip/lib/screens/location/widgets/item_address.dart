import 'package:cirilla/screens/screens.dart';
import 'package:feather_icons/feather_icons.dart';
import 'package:flutter/material.dart';
import 'package:cirilla/constants/constants.dart';

class ItemAddress extends StatelessWidget {
  final EdgeInsetsGeometry? padding;
  final GestureTapCallback? onTap;
  final bool isSelect;
  final bool addressBasic;

  ItemAddress({
    Key? key,
    this.padding,
    this.onTap,
    this.isSelect = false,
    this.addressBasic = false,
  }) : super(key: key);

  buildInfo(BuildContext context, ThemeData theme) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Home', style: theme.textTheme.subtitle2),
              Text('396 NY-52, Woodbourne, NY 12788', style: theme.textTheme.caption),
              Text('Mr. A   0379791336', style: theme.textTheme.bodyText2),
            ],
          ),
        ),
        SizedBox(width: itemPaddingMedium),
        Column(
          children: [
            InkResponse(
              onTap: () {
                Navigator.pushNamed(context, FormAddressScreen.routeName, arguments: {'address': {}});
              },
              radius: 25,
              child: Icon(FeatherIcons.edit, size: 20, color: theme.textTheme.caption!.color),
            ),
            if (isSelect) ...[
              SizedBox(height: layoutPadding),
              Icon(FeatherIcons.check, size: 20, color: theme.primaryColor),
            ],
          ],
        )
      ],
    );
  }

  buildBasic(ThemeData theme) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('396 NY-52', style: theme.textTheme.subtitle2),
              Text('Woodbourne, NY 12788', style: theme.textTheme.caption),
            ],
          ),
        ),
        if (isSelect) ...[
          SizedBox(width: itemPaddingMedium),
          if (isSelect) Icon(FeatherIcons.check, size: 20, color: theme.primaryColor),
        ]
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    ThemeData theme = Theme.of(context);
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: padding ?? EdgeInsets.zero,
        child: addressBasic ? buildBasic(theme) : buildInfo(context, theme),
      ),
    );
  }
}
