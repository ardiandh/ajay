import 'package:cirilla/constants/constants.dart';
import 'package:cirilla/mixins/mixins.dart';
import 'package:cirilla/screens/screens.dart';
import 'package:cirilla/store/store.dart';
import 'package:cirilla/widgets/cirilla_tile.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ui/ui.dart';

List<Map<String, String>> _types = [
  {
    'name': 'Home',
    'value': 'home',
  },
  {
    'name': 'Office',
    'value': 'office',
  },
  {
    'name': 'Other',
    'value': 'other',
  },
];

class FormAddressScreen extends StatefulWidget {
  static const routeName = '/location/form_address';

  final SettingStore? store;

  FormAddressScreen({
    Key? key,
    this.store,
  }) : super(key: key);

  @override
  _FormAddressScreenState createState() => _FormAddressScreenState();
}

class _FormAddressScreenState extends State<FormAddressScreen> with AppBarMixin {
  final _formKey = GlobalKey<FormState>();
  final _txtName = TextEditingController();
  final _txtPhone = TextEditingController();
  FocusNode? _phoneFocusNode;

  bool enableDefault = false;
  String type = 'home';

  String typeScreen = 'add';

  @override
  void didChangeDependencies() {
    dynamic args = ModalRoute.of(context)!.settings.arguments;
    dynamic data = args != null ? args!['address'] : null;
    _txtName.text = 'Marvin McKinney';
    _txtPhone.text = '(+88) 379791234';
    if (data != null) {
      setState(() {
        typeScreen = 'edit';
      });
    }
    super.didChangeDependencies();
  }

  @override
  void initState() {
    super.initState();
    _phoneFocusNode = FocusNode();
  }

  @override
  void dispose() {
    _txtName.dispose();
    _txtPhone.dispose();
    _phoneFocusNode!.dispose();
    super.dispose();
  }

  Widget buildHeading(String title, ThemeData theme) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: itemPaddingMedium, horizontal: layoutPadding),
      color: theme.colorScheme.surface,
      child: Text(
        title,
        style: theme.textTheme.caption!.copyWith(color: theme.textTheme.subtitle1!.color),
      ),
    );
  }

  Widget buildNameField() {
    return TextFormField(
      controller: _txtName,
      validator: (value) {
        if (value!.isEmpty) {
          return 'Empty';
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: 'Name',
      ),
      textInputAction: TextInputAction.next,
      onFieldSubmitted: (value) {
        FocusScope.of(context).requestFocus(_phoneFocusNode);
      },
    );
  }

  Widget buildPhoneField() {
    return TextFormField(
      controller: _txtPhone,
      focusNode: _phoneFocusNode,
      validator: (value) {
        if (value!.isEmpty) {
          return 'Empty';
        }
        return null;
      },
      keyboardType: TextInputType.phone,
      decoration: InputDecoration(
        labelText: 'Phone',
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    ThemeData theme = Theme.of(context);

    return Scaffold(
      appBar: baseStyleAppBar(context, title: typeScreen == 'edit' ? 'Edit Address' : 'New Address'),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(vertical: itemPaddingLarge, horizontal: layoutPadding),
        decoration: BoxDecoration(color: theme.scaffoldBackgroundColor, boxShadow: initBoxShadow),
        child: SizedBox(
          height: 48,
          child: ElevatedButton(
            onPressed: () {},
            child: Text('Save'),
            style: ElevatedButton.styleFrom(
              textStyle: theme.textTheme.subtitle2,
            ),
          ),
        ),
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  buildHeading('Contact', theme),
                  SizedBox(height: 16),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: layoutPadding),
                    child: Column(
                      children: [
                        buildNameField(),
                        SizedBox(height: 16),
                        buildPhoneField(),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  buildHeading('Address', theme),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: layoutPadding),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CirillaTile(
                          title: Text(
                            '396 NY-52, Woodbourne, NY 12788',
                            style: theme.textTheme.bodyText2?.copyWith(color: theme.textTheme.subtitle1!.color),
                          ),
                          onTap: () => Navigator.pushNamed(context, SelectLocationScreen.routeName),
                        ),
                        CirillaTile(
                          title: Text(
                            'Default address',
                            style: theme.textTheme.bodyText2?.copyWith(color: theme.textTheme.subtitle1!.color),
                          ),
                          trailing: CupertinoSwitch(
                            value: enableDefault,
                            onChanged: (_) => setState(() {
                              enableDefault = !enableDefault;
                            }),
                          ),
                          isChevron: false,
                        ),
                        SizedBox(height: 24),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: List.generate(_types.length, (index) {
                              Map<String, String> item = _types[index];
                              bool isSelected = item['value']! == type;
                              return Padding(
                                padding: EdgeInsetsDirectional.only(end: 8),
                                child: ButtonSelect.filter(
                                  child: Text(
                                    item['name']!,
                                    style: theme.textTheme.caption!.copyWith(color: theme.textTheme.subtitle1!.color),
                                  ),
                                  padding: EdgeInsets.symmetric(horizontal: 28, vertical: 8),
                                  isSelect: isSelected,
                                  colorSelect: theme.primaryColor,
                                  color: theme.colorScheme.surface,
                                  onTap: () => setState(() {
                                    if (!isSelected) {
                                      type = item['value']!;
                                    }
                                  }),
                                ),
                              );
                            }),
                          ),
                        ),
                        SizedBox(height: itemPaddingMedium),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          if (typeScreen == 'edit')
            SliverFillRemaining(
              hasScrollBody: false,
              fillOverscroll: true,
              child: Container(
                alignment: Alignment.bottomCenter,
                padding: EdgeInsets.symmetric(vertical: 22, horizontal: layoutPadding),
                child: Container(
                  height: 48,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text('Delete'),
                    style: ElevatedButton.styleFrom(
                      primary: theme.colorScheme.surface,
                      onPrimary: theme.textTheme.subtitle1!.color,
                      textStyle: theme.textTheme.subtitle2,
                      elevation: 0,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
