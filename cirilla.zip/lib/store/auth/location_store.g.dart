// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'location_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$LocationStore on _LocationStore, Store {
  Computed<UserLocation?>? _$locationComputed;

  @override
  UserLocation? get location =>
      (_$locationComputed ??= Computed<UserLocation?>(() => super.location, name: '_LocationStore.location')).value;

  final _$_locationAtom = Atom(name: '_LocationStore._location');

  @override
  UserLocation get _location {
    _$_locationAtom.reportRead();
    return super._location;
  }

  @override
  set _location(UserLocation value) {
    _$_locationAtom.reportWrite(value, super._location, () {
      super._location = value;
    });
  }

  final _$_savedAtom = Atom(name: '_LocationStore._saved');

  @override
  List<UserLocation>? get _saved {
    _$_savedAtom.reportRead();
    return super._saved;
  }

  @override
  set _saved(List<UserLocation>? value) {
    _$_savedAtom.reportWrite(value, super._saved, () {
      super._saved = value;
    });
  }

  final _$setLocationAsyncAction = AsyncAction('_LocationStore.setLocation');

  @override
  Future<void> setLocation({required double lat, required double lng, required String address, required String tag}) {
    return _$setLocationAsyncAction.run(() => super.setLocation(lat: lat, lng: lng, address: address, tag: tag));
  }

  @override
  String toString() {
    return '''
location: ${location}
    ''';
  }
}
