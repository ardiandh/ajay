enum ProductType {
  simple,
  grouped,
  external,
  variable,
  variation,
}
